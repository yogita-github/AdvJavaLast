package com.demo.test;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.demo.beans.Books;
import com.demo.service.JdbcService;
import com.demo.service.JdbcServiceImpl;

public class JdbcTest {

	public static void main(String[] args) throws SQLException {
		
		JdbcService service = new JdbcServiceImpl();
		Scanner sc = new Scanner(System.in);
		int choice;
		
				do {
				System.out.println("Enter your choice");
				System.out.println("1.Get All /n 2.Add Book /n 3.Update book /n 4.Delete book /n 5.exit");
				choice = sc.nextInt();
				switch(choice) {
				case 1:
				List<Books> blist= service.getAllbooks();
				for(Books book:blist) {
					System.out.println(book.getId() +" "+book.getType()+" "+book.getBookName()+" " + book.getCost());	
				}
					break;
				case 2:
					System.out.println("Enter book id");
					int id = sc.nextInt();
//					sc.next();
					System.out.println("Enter bookname");
					String bookName = sc.next();
					System.out.println("Enter book title");
					String Type = sc.next();
					System.out.println("Enter book price");
					int cost  = sc.nextInt();
					Books booklist = new Books(id,bookName,Type,cost);
					boolean res = service.addbook(booklist);
					if(res) {
						System.out.println("Book added successfully");
					}else {
						System.out.println("Book not added successfully");
					}
					break;
				case 3:
					System.out.println("Enter book id");
					id = sc.nextInt();
//					sc.next();
					sc.nextLine();
					System.out.println("Enter bookname");
					bookName = sc.nextLine();
					System.out.println("Enter book title");
					Type = sc.nextLine();
					System.out.println("Enter book price");
					cost  = sc.nextInt();
					booklist = new Books(id,bookName,Type,cost);
					res = service.updatebook(id,booklist);
					if(res) {
						System.out.println("Book updated successfully");
					}else {
						System.out.println("Book not updated ");
					}
					break;
				case 4:
					System.out.println("Enter book id");
					id = sc.nextInt();
					res= service.deletebyid(id);
					if(res) {
						System.out.println("deleted succesfully");
					}else {
						System.out.println("not deleted");
					}
					break;
				case 5:
					System.out.println("thanks for visiting");
					sc.close();
					break;
				default:
					System.out.println("Invalid choice");
					break;
				}
				}while(choice!=5);
					
			}
	}

