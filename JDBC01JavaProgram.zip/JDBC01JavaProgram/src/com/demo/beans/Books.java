package com.demo.beans;

public class Books {
	private int id;
	private String bookName;
	private String Type;
	private int cost;
	public Books() {}
	
	  public Books(int id, String bookName, String type, int cost) {
	        this.id = id;
	        this.bookName = bookName;
	        this.Type = type;
	        this.cost = cost;
	    }
	 public Books(String bookName, String type, int cost) {
		 	this.bookName = bookName;
		 	this.Type = type;
		 	this.cost = cost;
	}

	public int getId() { return id; }
	    public void setId(int id) { this.id = id; }

	    public String getBookName() { return bookName; }
	    public void setBookName(String bookName) { this.bookName = bookName; }

	    public String getType() { return Type; }
	    public void setType(String type) { this.Type = type; }

	    public int getCost() { return cost; }
	    public void setCost(int cost) { this.cost = cost; }

	public String toString() {
		return "Books [id=" + id + ", bookName=" + bookName + ", Type=" + Type + ", cost=" + cost + "]";
	}
	
	
	

}
