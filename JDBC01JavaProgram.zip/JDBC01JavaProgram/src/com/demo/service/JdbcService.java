package com.demo.service;

import java.sql.SQLException;
import java.util.List;

import com.demo.beans.Books;

public interface JdbcService {

	List<Books> getAllbooks() throws SQLException;

	boolean addbook(Books booklist) throws SQLException;

	boolean updatebook(int id, Books booklist) throws SQLException;

	boolean deletebyid(int id) throws SQLException;

}
