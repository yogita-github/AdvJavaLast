package com.demo.service;

import java.sql.SQLException;
import java.util.List;

import com.demo.beans.Books;
import com.demo.dao.BookDao;
import com.demo.dao.BookDaoImpl;

public class JdbcServiceImpl implements JdbcService{

	private BookDao bookdao = new BookDaoImpl();

	public List<Books> getAllbooks() throws SQLException {
		return bookdao.getAllBooks();
	}

	public boolean addbook(Books booklist) throws SQLException {
		return bookdao.AddBook(booklist);
	}

	public boolean updatebook(int id, Books booklist) throws SQLException {
		return bookdao.UpdateBook(id,booklist);
	}

	public boolean deletebyid(int id) throws SQLException {
		return bookdao.deletebyid(id);
	}

}
