package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtils {
	static Connection conn=null;
	public static Connection getMyConnection() throws SQLException {
		if(conn==null) {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			String url = "jdbc:mysql://localhost:3306/demo_iet";
			conn = DriverManager.getConnection(url,"root","Sweety@123");	
		}
		return conn;
	}
	public static void closeMyConnection() throws SQLException {
		if(conn!=null) {
			conn.close();
			conn=null;
		}
	}

}
