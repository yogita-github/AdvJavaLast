package com.demo.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Books;

public class BookDaoImpl implements BookDao{

	public List<Books> getAllBooks() throws SQLException {
		List<Books> blist = new ArrayList<>();
		Connection conn = DbUtils.getMyConnection();
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("select * from books");
		while(rs.next()) {
			Books book = new Books(
	                rs.getInt("id"),           //id
	                rs.getString("bookName"),  // bookName
	                rs.getString("type"),      // type
	                rs.getInt("cost")          // cost
	            );
	            blist.add(book);
		}
		rs.close();
		st.close();
		return blist;
	}


	public boolean AddBook(Books booklist) throws SQLException {
		Connection conn = DbUtils.getMyConnection();
		PreparedStatement pst = conn.prepareStatement("insert into books(id,bookName,Type,cost) values(?,?,?,?)");
		pst.setInt(1,booklist.getId());
		pst.setString(2,booklist.getBookName());
		pst.setString(3, booklist.getType());
		pst.setInt(4, booklist.getCost());
		pst.executeUpdate();
		pst.close();
		
		return true;
	}


	public boolean UpdateBook(int id, Books booklist) throws SQLException {
		Connection conn = DbUtils.getMyConnection();
		PreparedStatement pst = conn.prepareStatement("update books set bookName=? ,Type=?, cost=? where id=?");
		pst.setString(1,booklist.getBookName());
		pst.setString(2, booklist.getType());
		pst.setInt(3, booklist.getCost());
		pst.setInt(4,booklist.getId());
		pst.executeUpdate();
		pst.close();
		
		return true;
	}

	public boolean deletebyid(int id) throws SQLException {
		Connection con = DbUtils.getMyConnection();
		PreparedStatement pst  = con.prepareStatement("delete from books where id=?");
		pst.setInt(1, id);
		pst.executeUpdate();
		pst.close();
		return true;
	}


	
}
