package com.demo.dao;

import java.sql.SQLException;
import java.util.List;

import com.demo.beans.Books;

public interface BookDao {

	List<Books> getAllBooks() throws SQLException;

	boolean AddBook(Books booklist) throws SQLException;

	boolean UpdateBook(int id, Books booklist) throws SQLException;

	boolean deletebyid(int id) throws SQLException;

}
